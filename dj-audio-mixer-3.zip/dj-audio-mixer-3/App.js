import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import {Header} from 'react-native-elements';
import {Audio} from 'expo-av';
import SoundButton from './assets/soundButton';
import {
  SafeAreaView,
  SafeAreaProvider,
  SafeAreaInsetsContext,
  useSafeAreaInsets,
  initialWindowMetrics,
} from 'react-native-safe-area-context';

export default function App() {
  return (
    <SafeAreaProvider>
    <View >
      <Header centreComponent={{text:"DJ Audio Mixer",style:{color:'#87CEEB', fontSize:30}}}/>
      <View style={styles.container}>
        <SoundButton uri="https://d1490khl9dq1ow.cloudfront.net/audio/music/mp3preview/BsTwCwBHBjzwub4i4/rock-guitar-underscore-music-bed_MJhF2rB__NWM.mp3" text="Song 1" bgcolor="Red"/>
        </View>
        <View style={styles.container}>
        <SoundButton uri="https://d1490khl9dq1ow.cloudfront.net/audio/music/mp3preview/BsTwCwBHBjzwub4i4/bright-and-breezy-music-bed_MJA8hSHO_NWM.mp3" text="Song 2" bgcolor="blue"/>
        </View>
        <View style={styles.container}>
        <SoundButton uri="http://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/player_shoot.wav" text="Song 3" bgcolor="green"/>
        </View>
        <View style={styles.container}>
        <SoundButton uri="http://soundbible.com/grab.php?id=2217&type=mp3" text="Song 4" bgcolor="yellow"/>
        </View>
        <View style={styles.container}>
        <SoundButton uri="https://soundbible.com/2219-Airplane-Landing-Airport.html" text="Song 5" bgcolor="purple"/>
        </View>
        <View>
          <TouchableOpacity style={styles.stopbtn} onPress={()=>{
            Audio.setIsEnableAsync(false);
          }}>
            <Text>Stop</Text>
          </TouchableOpacity>
          </View>

    </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex:1, 
    justifyContent:'center', 
    alignItems:'center',
    marginTop:40
  },
  stopbtn:{
    width: '80%',
    height: 70,
    justifyContent:'center',
    alignItems:'center',
    borderRadius : 30,
    backgroundColor : 'red',
    borderWidth:2,
    marginTop:"50px",
    marginLeft:"30px",
    borderColor : 'rgba(0,0,0,0.3)',
  }
});
