import * as React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Audio } from 'expo-av';

import {
  SafeAreaView,
  SafeAreaProvider,
  SafeAreaInsetsContext,
  useSafeAreaInsets,
  initialWindowMetrics,
} from 'react-native-safe-area-context';

export default class SoundButton extends React.Component {
  playSound = async () => {
    await Audio.Sound.createAsync(
      {
        uri: this.props.uri,
      },
      {
        shouldPlay: true,
      }
    );
  };

  render() {
    return (
      <SafeAreaProvider>
        <View>
          <TouchableOpacity
            style={[styles.soundbtn, { backgroundColor: this.props.bgcolor }]}
            onPress={this.playSound}>
            <Text style={styles.btntext}>{this.props.text}</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaProvider>
    );
  }
}

const styles = StyleSheet.create({
  soundbtn: {
    width: 200,
    height: 100,
    borderRadius: 50,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: 'rgba(0,0,0,0.2)',
  },
  btntext: {
    fontFamily: 'Trebuchet MS',
    fontSize: 20,
  },
});
